﻿--1	Cho biết những Bộ Môn nào có nhiều Giáo Viên nhất có Số Điện Thoại.
SELECT BM.MABM, BM.TENBM, COUNT(DISTINCT DT.MAGV) AS SLGV
FROM BOMON BM 
	JOIN GIAOVIEN GV ON BM.MABM = GV.MABM
	JOIN GV_DT DT ON GV.MAGV = DT.MAGV
GROUP BY BM.MABM, BM.TENBM
HAVING COUNT(DISTINCT DT.MAGV) >= ALL(
	SELECT COUNT(DISTINCT DT.MAGV) AS SLGV
	FROM BOMON BM 
		JOIN GIAOVIEN GV ON BM.MABM = GV.MABM
		JOIN GV_DT DT ON GV.MAGV = DT.MAGV
	GROUP BY BM.MABM
)
--2	Cho biết những Giáo Viên nào có tham gia tất cả các Đề Tài của Giáo Viên “Trương Nam Sơn” làm chủ nhiệm đề tài.
SELECT DISTINCT GV.MAGV, GV.HOTEN
FROM GIAOVIEN GV JOIN THAMGIADT TG ON GV.MAGV = TG.MAGV
WHERE NOT EXISTS(
	SELECT DT.MADT
	FROM DETAI DT JOIN GIAOVIEN GV ON DT.GVCNDT = GV.MAGV AND GV.HOTEN = N'Trương Nam Sơn'
	EXCEPT
	SELECT DISTINCT MADT
	FROM THAMGIADT TG1
	WHERE TG1.MAGV = TG.MAGV
)
--3	Cho biết những Giáo Viên nào mà tất cả các Đề Tài mình tham gia đều có Kinh Phí trên 80 triệu.
SELECT DISTINCT GV.MAGV, GV.HOTEN
FROM GIAOVIEN GV JOIN THAMGIADT TG ON GV.MAGV = TG.MAGV
WHERE NOT EXISTS(
	SELECT *
	FROM THAMGIADT TG1 JOIN DETAI DT ON TG1.MADT = DT.MADT
	WHERE DT.KINHPHI <= 80 AND TG1.MAGV = TG.MAGV
)
--4	Viết stored procedure "spHienThi_DSGV_ThamGia_DeTai" với tham số vào (Từ_Ngày, Đến_Ngày) với nội dung như sau:
--•	Kiểm tra giá trị đầu vào có hợp lệ không (Từ_Ngày phải nhỏ hơn Đến_Ngày). Nếu không thì báo lỗi & kết thúc.
--•	Xác định các đề tài có thời gian thực hiện nằm trong khoảng thời gian theo yêu cầu.
--•	In thông báo số lượng đề tài thỏa yêu cầu. Nếu = 0 thì kết thúc.
--•	Với mỗi đề tài trong khoảng thời gian theo yêu cầu (đề tài mới nhất bắt đầu trước, cũ nhất sau cùng) :
--o	 Xuất tất cả thông tin của đề tài đó kèm theo Số lượng GV tham gia đề tài đó (bỏ qua GVCNDT nếu có).
--o	Xuất thông tin GV làm chủ nhiệm đề tài đó.
--o	Xuất danh sách GV tham gia đề tài đó (bỏ qua GVCNDT nếu có) theo tuổi giảm dần.
DROP PROCEDURE spHienThi_DSGV_ThamGia_DeTai

GO

CREATE PROCEDURE spHienThi_DSGV_ThamGia_DeTai @TU_NGAY DATE, @DEN_NGAY DATE
AS
BEGIN
	IF (@TU_NGAY > @DEN_NGAY)
	BEGIN
		RAISERROR('Từ_Ngày phải nhỏ hơn Đến_Ngày', 16, 1)
		RETURN
	END
	ELSE
	BEGIN
		DECLARE @VTABLE TABLE(MADT CHAR(5), GVCNDT CHAR(5))

		INSERT INTO @VTABLE
		SELECT MADT, GVCNDT
		FROM DETAI
		WHERE (NGAYBD BETWEEN @TU_NGAY AND @DEN_NGAY) AND (NGAYKT BETWEEN @TU_NGAY AND @DEN_NGAY)
		ORDER BY NGAYBD DESC

		DECLARE @CNT INT, @MADT CHAR(5), @GVCNDT CHAR(5)

		SELECT @CNT = COUNT(*) FROM @VTABLE

		IF (@CNT = 0)
		BEGIN
			RAISERROR('Bảng không có thông tin', 16, 1)
			RETURN
		END
		ELSE
		BEGIN
			WHILE (@CNT > 0)
			BEGIN
				SELECT TOP 1 @MADT = MADT, @GVCNDT = GVCNDT
				FROM @VTABLE

				DECLARE @SL_GVTG INT
				SET @SL_GVTG = (SELECT COUNT(DISTINCT MAGV) FROM THAMGIADT WHERE MADT = @MADT AND MAGV <> @GVCNDT)

				SELECT *, @SL_GVTG AS SLGV
				FROM DETAI 
				WHERE MADT = @MADT 

				SELECT *
				FROM GIAOVIEN 
				WHERE MAGV = @GVCNDT

				SELECT GV.*
				FROM GIAOVIEN GV
				WHERE GV.MAGV <> @GVCNDT AND
					GV.MAGV IN (SELECT DISTINCT TG.MAGV
								FROM THAMGIADT TG
								WHERE TG.MADT = @MADT )
				ORDER BY (YEAR(GETDATE()) - YEAR(GV.NGSINH)) DESC;

			
				DELETE FROM @VTABLE WHERE MADT = @MADT
				SET @CNT = @CNT - 1
			END
		END
	END
END

--EXEC spHienThi_DSGV_ThamGia_DeTai '2010-1-1', '2008-1-1'

EXEC spHienThi_DSGV_ThamGia_DeTai '2006-10-20', '2010-05-15'
