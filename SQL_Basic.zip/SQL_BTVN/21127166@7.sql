﻿

--Q75. Cho biết họ tên giáo viên và tên bộ môn họ làm trưởng bộ môn nếu có
SELECT GV.HOTEN, COALESCE (BM.TENBM, 'Unknown') AS BO_MON
FROM GIAOVIEN GV LEFT JOIN BOMON BM ON GV.MAGV = BM.TRUONGBM

--Q76. Cho danh sách tên bộ môn và họ tên trưởng bộ môn đó nếu có
SELECT BM.TENBM, COALESCE (GV.HOTEN, 'Unknown') AS TRUONG_BO_MON
FROM GIAOVIEN GV RIGHT JOIN BOMON BM ON GV.MAGV = BM.TRUONGBM

--Q77. Cho danh sách tên giáo viên và các đề tài giáo viên đó chủ nhiệm nếu có
SELECT GV.HOTEN, COALESCE (DT.TENDT, 'Unknown') AS DE_TAI
FROM GIAOVIEN GV LEFT JOIN DETAI DT ON GV.MAGV = DT.GVCNDT

--Q78. Xuất ra thông tin của giáo viên (MAGV, HOTEN) và mức lương của giáo viên. Mức lương được xếp theo Quy tắc: Lương của giáo viên < $1800 : “THẤP” ; Từ $1800 đến $2200: TRUNG BÌNH; Lương > $2200: “CAO”
SELECT MAGV, HOTEN, 
	(CASE
		WHEN LUONG < 1800 THEN N'THẤP'
		WHEN LUONG > 2200 THEN N'CAO'
		ELSE N'TRUNG BÌNH'
	 END) AS MUC_LUONG
FROM GIAOVIEN

--Q79. Xuất ra thông tin giáo viên (MAGV, HOTEN) và xếp hạng dựa vào mức lương. Nếu giáo viên có lương cao nhất thì hạng là 1.
SELECT MAGV ,HOTEN, RANK () OVER (ORDER BY LUONG) AS Rank_no 
FROM GIAOVIEN
--Q80. Xuất ra thông tin thu nhập của giáo viên. Thu nhập của giáo viên được tính bằng LƯƠNG + PHỤ CẤP. Nếu giáo viên là trưởng bộ môn thì PHỤ CẤP là 300, và giáo viên là trưởng khoa thì PHỤ CẤP là 600.
SELECT HOTEN, (LUONG + 
(CASE 
	WHEN MAGV IN (SELECT TRUONGBM FROM BOMON) THEN 300 
	WHEN MAGV IN (SELECT TRUONGKHOA FROM KHOA) THEN 600
	ELSE 0
END)) AS THU_NHAP
FROM GIAOVIEN
--Q81. Xuất ra năm mà giáo viên dự kiến sẽ nghĩ hưu với quy định: Tuổi nghỉ hưu của Nam là 60, của Nữ là 55.
SELECT HOTEN, (YEAR(NGSINH) + 
(CASE
	WHEN PHAI = N'Nam' THEN 60
	ELSE 55
END)) AS NAM_NGHI_HUU_DU_KIEN
FROM GIAOVIEN

--Q82. Cho biết danh sách tất cả giáo viên (magv, hoten) và họ tên giáo viên là quản lý chuyên môn của họ.
SELECT GV.MAGV, GV.HOTEN, GV1.HOTEN
FROM GIAOVIEN GV LEFT JOIN GIAOVIEN GV1 ON GV.GVQLCM = GV1.MAGV

--Q83. Cho biết danh sách tất cả bộ môn (mabm, tenbm), tên trưởng bộ môn cùng số lượng giáo viên của mỗi bộ môn.
SELECT BM.MABM, BM.TENBM, GV.HOTEN AS TRUONG_B0_MON, T.SO_LUONG AS SO_LUONG_GV 
FROM BOMON BM 
LEFT JOIN GIAOVIEN GV ON BM.TRUONGBM = GV.MAGV
LEFT JOIN (
	SELECT BM.MABM , COUNT(GV.MAGV) AS SO_LUONG 
	FROM BOMON BM LEFT JOIN GIAOVIEN GV ON BM.MABM = GV.MABM 
	GROUP BY BM.MABM
) AS T ON BM.MABM = T.MABM

--Q84. Cho biết danh sách tất cả các giáo viên nam và thông tin các công việc mà họ đã tham gia.
SELECT GV.MAGV, GV.HOTEN, CV.*
FROM GIAOVIEN GV INNER JOIN THAMGIADT TG ON GV.MAGV = TG.MAGV
INNER JOIN CONGVIEC CV ON TG.MADT = CV.MADT AND TG.STT = CV.SOTT
WHERE GV.PHAI = N'Nam'

--Q85. Cho biết danh sách tất cả các giáo viên và thông tin các công việc thuộc đề tài 001 mà họ tham gia.
SELECT GV.MAGV, GV.HOTEN, CV.*
FROM GIAOVIEN GV INNER JOIN THAMGIADT TG ON GV.MAGV = TG.MAGV
INNER JOIN CONGVIEC CV ON TG.MADT = CV.MADT AND TG.STT = CV.SOTT
WHERE TG.MADT = '001'
ORDER BY GV.MAGV
--Q86. Cho biết thông tin các trưởng bộ môn (magv, hoten) sẽ về hưu vào năm 2014. Biết rằng độ tuổi về hưu của giáo viên nam là 60 còn giáo viên nữ là 55.
SELECT GV.MAGV, GV.HOTEN
FROM GIAOVIEN GV INNER JOIN BOMON BM ON GV.MAGV = BM.TRUONGBM
WHERE YEAR(GV.NGSINH) + (CASE WHEN GV.PHAI = N'Nam' THEN 60 ELSE 55 END) = 2014 

--Q87. Cho biết thông tin các trưởng khoa (magv) và năm họ sẽ về hưu.
SELECT MAGV, (YEAR(NGSINH) + (CASE WHEN PHAI = N'Nam' THEN 60 ELSE 55 END)) AS NAM_VE_HUU
FROM GIAOVIEN 
WHERE MAGV IN (SELECT TRUONGKHOA FROM KHOA)

--Q88. Tạo bảng DANHSACHTHIDUA (magv, sodtdat, danhhieu) gồm thông tin mã giáo viên, số đề tài họ tham gia đạt kết quả và danh hiệu thi đua:
CREATE TABLE DANHSACHTHIDUA(
	MAGV CHAR(5),
	SODTDAT TINYINT,
	DANHHIEU NVARCHAR(30),
	PRIMARY KEY(MAGV)
)
	--a. Insert dữ liệu cho bảng này (để trống cột danh hiệu)
INSERT INTO DANHSACHTHIDUA (MAGV, SODTDAT)
SELECT GV.MAGV, COUNT(CASE TG.KETQUA WHEN N'Đạt' THEN 1 ELSE NULL END) AS SODTDAT
FROM GIAOVIEN GV JOIN THAMGIADT TG ON GV.MAGV = TG.MAGV
--WHERE TG.KETQUA = N'Đạt'
GROUP BY GV.MAGV

	--b. Dựa vào cột sldtdat (số lượng đề tài tham gia có kết quả là “đạt”) để cập nhật dữ liệu cho cột danh hiệu theo --Quy định:
		--i. Sodtdat = 0 thì danh hiệu “chưa hoàn thành nhiệm vụ”
		--ii. 1 <= Sodtdat <= 2 thì danh hiệu “hoàn thành nhiệm vụ”
		--iii. 3 <= Sodtdat <= 5 thì danh hiệu “tiên tiến”
		--iv. Sodtdat >= 6 thì danh hiệu “lao động xuất sắc”

UPDATE DANHSACHTHIDUA
SET DANHHIEU = (
CASE 
	WHEN SODTDAT = 0 THEN N'chưa hoàn thành nhiệm vụ'
	WHEN SODTDAT IN (1,2) THEN N'hoàn thành nhiệm vụ'
	WHEN SODTDAT IN (3,5) THEN N'tiên tiến'
	ELSE N'lao động xuất sắc'
END)

--Q89. Cho biết magv, họ tên và mức lương các giáo viên nữ của khoa “Công nghệ thông tin”, mức lương trung bình, mức lương lớn nhất và nhỏ nhất của các giáo viên này.
SELECT GV.MAGV, GV.HOTEN, AVG(GV.LUONG)
FROM GIAOVIEN GV JOIN BOMON BM ON GV.MABM = BM.MABM AND GV.PHAI = N'Nữ' AND BM.MAKHOA IN (SELECT MAKHOA FROM KHOA WHERE TENKHOA = N'Công nghệ thông tin' )
GROUP BY GV.MAGV, GV.HOTEN
COMPUTE AVG(GV.LUONG);

--Q90. Cho biết makhoa, tenkhoa, số lượng gv từng khoa, số lượng gv trung bình, lớn nhất và nhỏ nhất của các khoa này.

--Q91. Cho biết danh sách các tên chủ đề, kinh phí cho chủ đề (là kinh phí cấp cho các đề tài Bộ môn Hệ thống thông tin | Khoa CNTT | ĐH KHTN TP HCM Trang 15 thuộc chủ đề), tổng kinh phí, kinh phí lớn nhất và nhỏ nhất cho các chủ đề.
--Q92. Cho biết madt, tendt, kinh phí đề tài, mức kinh phí tổng và trung bình của các đề tài này theo từng giáo viên chủ nhiệm.
SELECT MADT, TENDT, KINHPHI
FROM DETAI
ORDER BY GVCNDT
COMPUTE SUM(KINHPHI) BY GVCNDT
--Q93. Cho biết madt, tendt, kinh phí đề tài, mức kinh phí tổng và trung bình của các đề tài này theo từng cấp độ đề tài.
--Q94. Tổng hợp số lượng các đề tài theo (cấp độ, chủ đề), theo (cấp độ), theo (chủ đề).
SELECT DT.CAPQL, CD.TENCD, COUNT(DT.MADT) AS SO_LUONG_DT, GROUPING(DT.CAPQL) 'GRP'
FROM DETAI DT JOIN CHUDE CD ON DT.MACD = CD.MACD
GROUP BY DT.CAPQL, CD.TENCD WITH CUBE

--Q95. Tổng hợp mức lương tổng của các giáo viên theo (bộ môn, phái), theo (bộ môn).
SELECT MABM, PHAI, SUM(LUONG) AS MUC_LUONG_TONG, GROUPING(MABM) AS 'GRP'
FROM GIAOVIEN
GROUP BY MABM, PHAI WITH ROLLUP


--Q96. Tổng hợp số lượng các giáo viên của khoa CNTT theo (bộ môn, lương), theo (bộ môn), theo (lương).
SELECT MABM, LUONG, COUNT(MAGV) AS SO_LUONG_GV
FROM GIAOVIEN 
WHERE MABM IN (SELECT MABM FROM BOMON WHERE MAKHOA = 'CNTT')
GROUP BY MABM, LUONG WITH CUBE
ORDER BY MABM, LUONG