﻿--T1. Tên đề tài phải duy nhất 
CREATE TRIGGER trgTENDETAI
ON DETAI
FOR INSERT, UPDATE
AS
IF UPDATE(TENDT)
BEGIN
	IF (EXISTS(SELECT * FROM INSERTED I WHERE I.TENDT IN (SELECT TENDT FROM DETAI)))
	BEGIN
		raiserror (N'Lỗi: Tên đề tài đã tồn tại.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgTENDETAI

--TEST--
INSERT INTO DETAI
    (MADT, TENDT, CAPQL, KINHPHI, NGAYBD, NGAYKT, MACD, GVCNDT)
VALUES
    ('008', N'HTTT quản lý các trường ĐH', N'ĐHQG', 20.0 , CAST(N'2007-10-20' AS Date), CAST(N'2008-10-20' AS Date), 'QLGD', '002')

GO

--T2. Trưởng bộ môn phải sinh sau trước 1975 
CREATE TRIGGER trgCAPNHATNAMSINH
ON BOMON
FOR INSERT, UPDATE
AS
IF UPDATE(TRUONGBM)
BEGIN
	IF (EXISTS(SELECT GV.MAGV FROM GIAOVIEN GV WHERE GV.MAGV IN (SELECT I.TRUONGBM FROM inserted I) AND YEAR(GV.NGSINH) >= 1975))
	BEGIN
		raiserror (N'Lỗi: Các trưởng bộ môn phải sinh trước 1975', 16, 1)
		rollback
	END
END

DROP TRIGGER trgCAPNHATNAMSINH

--TEST--
UPDATE BOMON
SET TRUONGBM = '003'
WHERE MABM = 'HTTT'

GO

--T3. Một bộ môn có tối thiểu 1 giáo viên nữ
CREATE TRIGGER trgPHAI_GIAOVIEN_CAPNHAT
ON GIAOVIEN
FOR INSERT, UPDATE
AS
IF UPDATE(PHAI)
BEGIN
	IF(EXISTS(SELECT * FROM inserted I WHERE I.PHAI = N'Nam'))
	BEGIN
		DECLARE @COUNT INT
		SELECT @COUNT = COUNT(GV.MAGV) FROM GIAOVIEN GV, inserted I WHERE GV.MABM = I.MABM AND GV.PHAI = N'Nữ'
		IF(@COUNT = 0)
		BEGIN
			raiserror (N'Lỗi: Mỗi bộ môn phải có tối thiểu một giáo viên nữ.', 16, 1)
			rollback
		END
	END
END

DROP TRIGGER trgPHAI_GIAOVIEN_CAPNHAT

GO

CREATE TRIGGER trgPHAI_GIAOVIEN_XOA
ON GIAOVIEN
FOR DELETE
AS
BEGIN
	IF(EXISTS(SELECT * FROM deleted WHERE PHAI = N'Nữ'))
	BEGIN
		DECLARE @MABM CHAR(5)
		SELECT @MABM = MABM FROM deleted

		DECLARE @CNT INT
		SELECT @CNT = COUNT(*) FROM GIAOVIEN WHERE MABM = @MABM AND PHAI = N'Nữ'
		PRINT(@CNT)

		IF (@CNT = 0)
		BEGIN
			raiserror (N'Lỗi: Mỗi bộ môn phải có tối thiểu một giáo viên nữ.', 16, 1)
			rollback
		END	
	END
END

DROP TRIGGER trgPHAI_GIAOVIEN_XOA

--TEST--
UPDATE GIAOVIEN
SET PHAI = N'Nữ'
WHERE MAGV = '002'

DELETE FROM GIAOVIEN
WHERE MAGV = '006'

insert into GIAOVIEN values ('006',N'Trần Bạch Tuyết',1500,N'Nữ','05/20/1980',N'127	Hùng Vương, TP Mỹ Tho','004',N'VS')

GO

--T4. Một giáo viên phải có ít nhất 1 số điện thoại 
CREATE TRIGGER trgDIENTHOAI_GVDT_XOA
ON GV_DT
FOR DELETE
AS
BEGIN
	DECLARE @COUNT INT
	SELECT @COUNT = COUNT(GD.DIENTHOAI) FROM DELETED D, GV_DT GD WHERE GD.MAGV = D.MAGV
	IF(@COUNT = 0)
	BEGIN
		raiserror (N'Lỗi: Một giáo viên phải có ít nhất 1 số điện thoại.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgDIENTHOAI_GVDT_XOA

--TEST--
DELETE FROM GV_DT
WHERE DIENTHOAI = '0913454545'

INSERT INTO GV_DT
    (MAGV, DIENTHOAI)
VALUES
('002', '0913454545')

GO
--T5. Một giáo viên có tối đa 3 số điện thoại 
CREATE TRIGGER trgDIENTHOAI_GVDT_CAPNHAT
ON GV_DT
FOR INSERT, UPDATE
AS
IF UPDATE(DIENTHOAI)
BEGIN
	DECLARE @COUNT INT
	SELECT @COUNT = COUNT(GD.DIENTHOAI) FROM INSERTED I, GV_DT GD WHERE GD.MAGV = I.MAGV
	IF(@COUNT > 3)
	BEGIN
		raiserror (N'Lỗi: Một giáo viên có tối đa 3 số điện thoại.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgDIENTHOAI_GVDT_CAPNHAT

GO

--TEST--
INSERT INTO GV_DT
VALUES('003', '0000000000')

DELETE FROM GV_DT
WHERE DIENTHOAI = '0000000000'

GO
--T6. Một bộ môn phải có tối thiểu 4 giáo viên 
CREATE TRIGGER trgXOAGIAOVIEN
ON GIAOVIEN
FOR DELETE
AS
BEGIN
	DECLARE @COUNT INT
	SELECT @COUNT = COUNT(GV.MAGV) FROM DELETED D, GIAOVIEN GV WHERE GV.MABM = D.MABM
	IF(@COUNT < 4)
	BEGIN
		raiserror (N'Lỗi: Một bộ môn phải có tối thiểu 4 giáo viên.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgXOAGIAOVIEN

--TEST--
DELETE FROM GIAOVIEN
WHERE MAGV = '008'

INSERT INTO DETAI
    (MADT, TENDT, CAPQL, KINHPHI, NGAYBD, NGAYKT, MACD, GVCNDT)
VALUES
    ('008', N'HTTT quản lý các trường ĐH', N'ĐHQG', 20.0 , CAST(N'2007-10-20' AS Date), CAST(N'2008-10-20' AS Date), 'QLGD', '002')

GO
--T7. Trưởng bộ môn phải là người lớn tuổi nhất trong bộ môn. 
CREATE TRIGGER trgNAMSINH_TRUONGBM_BOMON
ON BOMON
FOR INSERT, UPDATE
AS
IF UPDATE(TRUONGBM)
BEGIN
	DECLARE @MIN_YEAR INT
	SELECT @MIN_YEAR = MIN(YEAR(NGSINH)) FROM GIAOVIEN WHERE MABM IN (SELECT MABM FROM inserted)
	IF(NOT EXISTS(SELECT * FROM GIAOVIEN GV, inserted I WHERE GV.MABM = I.MABM AND I.TRUONGBM = GV.MAGV AND YEAR(GV.NGSINH) = @MIN_YEAR))
	BEGIN
		raiserror (N'Lỗi: Trưởng bộ môn phải là người lớn tuổi nhất trong bộ môn.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgNAMSINH_TRUONGBM_BOMON

GO

CREATE TRIGGER trgNAMSINH_TRUONGBM_GIAOVIEN
ON GIAOVIEN 
FOR INSERT, UPDATE
AS
IF UPDATE(NGSINH)
BEGIN
	DECLARE @TR_BM CHAR(5)
	SELECT @TR_BM = BM.TRUONGBM FROM inserted I INNER JOIN BOMON BM ON I.MABM = BM.MABM

	DECLARE @DOB_TR_BM INT
	SELECT @DOB_TR_BM = YEAR(NGSINH) FROM GIAOVIEN WHERE MAGV = @TR_BM

	DECLARE @DOB INT
	SELECT @DOB = YEAR(NGSINH) FROM inserted
	IF (@DOB < @DOB_TR_BM)
	BEGIN
		raiserror (N'Lỗi: Trưởng bộ môn phải là người lớn tuổi nhất trong bộ môn.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgNAMSINH_TRUONGBM_GIAOVIEN

--TEST--
UPDATE BOMON 
SET TRUONGBM = '008'
WHERE MABM = 'HPT'

GO
--T8. Nếu một giáo viên đã là trưởng bộ môn thì giáo viên đó không làm người quản lý chuyên 
--môn.
CREATE TRIGGER trgTRBM_QLCM_BOMON
ON BOMON
FOR UPDATE
AS
IF UPDATE(TRUONGBM)
BEGIN
	IF(EXISTS(SELECT * FROM inserted WHERE TRUONGBM IN (SELECT GVQLCM FROM GIAOVIEN )))
	BEGIN
		raiserror (N'Lỗi: Nếu một giáo viên đã là trưởng bộ môn thì giáo viên đó không làm người quản lý chuyên môn.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgTRBM_QLCM_BOMON

UPDATE BOMON
SET TRUONGBM = '001'
WHERE MABM = 'MMT'

GO

CREATE TRIGGER trgTRBM_QLCM_GIAOVIEN
ON GIAOVIEN
FOR UPDATE
AS
IF UPDATE(GVQLCM)
BEGIN
	IF(EXISTS(SELECT * FROM inserted WHERE GVQLCM IN (SELECT TRUONGBM FROM BOMON)))
	BEGIN
		raiserror (N'Lỗi: Nếu một giáo viên đã là trưởng bộ môn thì giáo viên đó không làm người quản lý chuyên môn.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgTRBM_QLCM_GIAOVIEN

UPDATE GIAOVIEN
SET GVQLCM = '002'
WHERE MAGV = '003'

GO
--T9. Giáo viên và giáo viên quản lý chuyên môn của giáo viên đó phải thuộc về 1 bộ môn. 
CREATE TRIGGER trgGV_GVQLCM
ON GIAOVIEN 
FOR INSERT, UPDATE
AS
IF UPDATE(GVQLCM)
BEGIN
	IF(NOT EXISTS(SELECT * FROM inserted I, GIAOVIEN GV WHERE I.MAGV = GV.MAGV AND GV.MABM = (SELECT GV1.MABM FROM GIAOVIEN GV1, inserted I1 WHERE I1.GVQLCM = GV1.MAGV)))
	BEGIN
		raiserror (N'Lỗi: Giáo viên và giáo viên quản lý chuyên môn của giáo viên đó phải thuộc về 1 bộ môn.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgGV_GVQLCM

INSERT INTO GIAOVIEN
    (MAGV, HOTEN, LUONG, PHAI, NGSINH, DIACHI, GVQLCM, MABM)
VALUES
    ('011', N'Nguyễn Hoài', 2000.0 , N'Nam', CAST(N'1973-02-15' AS Date), N'25/3 Lạc Long Quân, Q.10, TP HCM', '002', 'MMT')

DELETE FROM GIAOVIEN
WHERE MAGV = '011'
--T10.Mỗi giáo viên chỉ có tối đa 1 vợ chồng 
--T11.Giáo viên là Nam thì chỉ có vợ là Nữ hoặc ngược lại. 
--T12.Nếu thân nhân có quan hệ là “con gái” hoặc “con trai” với giáo viên thì năm sinh của giáo 
--viên phải nhỏ hơn năm sinh của thân nhân. 
--T13.Một giáo viên chỉ làm chủ nhiệm tối đa 3 đề tài. 
GO
CREATE TRIGGER trgCHUNHIEMDETAI
ON DETAI 
FOR INSERT, UPDATE
AS
IF UPDATE(GVCNDT)
BEGIN
	DECLARE @COUNT INT
	SELECT @COUNT = COUNT(DT.MADT) FROM DETAI DT WHERE DT.GVCNDT IN (SELECT GVCNDT FROM inserted)
	IF(@COUNT > 3)
	BEGIN
		raiserror (N'Lỗi: Một giáo viên chỉ làm chủ nhiệm tối đa 3 đề tài.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgCHUNHIEMDETAI

INSERT INTO DETAI
    (MADT, TENDT, CAPQL, KINHPHI, NGAYBD, NGAYKT, MACD, GVCNDT)
VALUES
    ('009', N'HTTT ĐH', N'ĐHQG', 20.0 , CAST(N'2007-10-20' AS Date), CAST(N'2008-10-20' AS Date), 'QLGD', '002')

DELETE FROM DETAI
WHERE MADT = '008'

GO
--T14.Một đề tài phải có ít nhất một công việc 
CREATE TRIGGER trgCONGVIEC_DETAI
ON CONGVIEC
FOR DELETE
AS
BEGIN
	BEGIN
	DECLARE @CNT INT
	SELECT @CNT = COUNT(*) FROM DELETED D INNER JOIN CONGVIEC CV ON D.MADT = CV.MADT AND D.SOTT = CV.SOTT
	IF(@CNT = 0)
	BEGIN
		raiserror (N'Lỗi: Một đề tài phải có ít nhất một công việc.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgCONGVIEC_DETAI


--T15.Lương của giáo viên phải nhỏ hơn lương người quản lý của giáo viên đó. 
GO
CREATE TRIGGER trgLUONG_GV_GVQLCM
ON GIAOVIEN 
FOR INSERT, UPDATE
AS
IF UPDATE(LUONG)
BEGIN
	IF(EXISTS(SELECT * FROM GIAOVIEN GV, inserted I WHERE GV.MAGV = I.MAGV AND GV.LUONG > (SELECT GV1.LUONG FROM GIAOVIEN GV1, inserted I1 WHERE GV1.MAGV = I1.GVQLCM)))
	BEGIN
		raiserror (N'Lỗi: Lương của giáo viên phải nhỏ hơn lương người quản lý của giáo viên đó.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgLUONG_GV_GVQLCM

UPDATE GIAOVIEN
SET LUONG = 2200
WHERE MAGV = '003'

GO

--T16.Lương của trưởng bộ môn phải lớn hơn lương của các giáo viên trong bộ môn. 
CREATE TRIGGER trgLUONG_BOMON_TRUONGBM
ON BOMON
FOR INSERT, UPDATE
AS 
IF UPDATE(TRUONGBM)
BEGIN
	IF(EXISTS(SELECT * FROM GIAOVIEN GV JOIN inserted I ON GV.MAGV = I.TRUONGBM WHERE GV.LUONG <= (SELECT MAX(LUONG) FROM GIAOVIEN WHERE MABM = GV.MABM AND MAGV != I.TRUONGBM)))
	BEGIN
		raiserror (N'Lỗi: Lương của trưởng bộ môn phải lớn hơn lương của các giáo viên trong bộ môn.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgLUONG_BOMON_TRUONGBM

UPDATE BOMON
SET TRUONGBM = '003'
WHERE MABM = 'HTTT'

GO

CREATE TRIGGER trgLUONG_GIAOVIEN_TRUONGBM
ON GIAOVIEN
FOR INSERT, UPDATE
AS
IF UPDATE(MAGV)
BEGIN
	IF(EXISTS(SELECT * FROM GIAOVIEN GV JOIN inserted I ON GV.MABM = I.MABM WHERE GV.LUONG > (SELECT GV1.LUONG FROM GIAOVIEN GV1 JOIN BOMON BM1 ON GV1.MAGV = BM1.TRUONGBM WHERE BM1.MABM = I.MABM)))
	BEGIN
		raiserror (N'Lỗi: Lương của trưởng bộ môn phải lớn hơn lương của các giáo viên trong bộ môn.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgLUONG_GIAOVIEN_TRUONGBM

insert into GIAOVIEN values ('011',N'Nguyễn Hoài',2200,N'Nam','02/15/1973',N'25/3 Lạc Long Quân, Q.10, TP HCM', null, N'MMT')

DELETE FROM GIAOVIEN
WHERE MAGV = '011'

GO
--T17.Bộ môn ban nào cũng phải có trưởng bộ môn và trưởng bộ môn phải là một giáo viên trong trường.  ?
CREATE TRIGGER trgTRUONGBM_BOMON
ON BOMON
FOR INSERT, UPDATE
AS
IF UPDATE(TRUONGBM)
BEGIN
	IF(EXISTS(SELECT * FROM inserted WHERE TRUONGBM IS NULL) OR EXISTS(SELECT * FROM inserted I WHERE I.TRUONGBM IN (SELECT GV.MAGV FROM GIAOVIEN GV WHERE I.MABM = GV.MABM)))
	BEGIN
		raiserror (N'Lỗi: Bộ môn ban nào cũng phải có trưởng bộ môn và trưởng bộ môn phải là một giáo viên trong trường.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgTRUONGBM_BOMON

UPDATE BOMON
SET TRUONGBM = '011'
WHERE MABM = 'HTTT'

GO
--T18.Một giáo viên chỉ quản lý tối đa 3 giáo viên khác. 
CREATE TRIGGER trg_GIAOVIEN_GVQLCM
ON GIAOVIEN
FOR INSERT, UPDATE
AS
IF UPDATE(GVQLCM)
BEGIN
	DECLARE @GVQL CHAR(5)
	SELECT @GVQL = GVQLCM FROM inserted
	PRINT(@GVQL)
	DECLARE @CNT INT
	SELECT @CNT = COUNT(*) FROM GIAOVIEN WHERE GVQLCM = @GVQL
	PRINT (@CNT)
	IF(@CNT - 1 > 2)
	BEGIN
		raiserror (N'Lỗi: Một giáo viên chỉ quản lý tối đa 3 giáo viên khác.', 16, 1)
		rollback
	END
END

DROP TRIGGER trg_GIAOVIEN_GVQLCM

SELECT * FROM GIAOVIEN GV WHERE GV.GVQLCM = '007'

UPDATE GIAOVIEN
SET GVQLCM = NULL
WHERE MAGV = '004'

GO
--T19.Giáo viên chỉ tham gia những đề tài mà giáo viên chủ nhiệm đề tài là người cùng bộ môn với giáo viên đó.
CREATE TRIGGER trgMAGV_THAMGIADT
ON THAMGIADT
FOR INSERT, UPDATE
AS
IF UPDATE(MADT)
BEGIN
	DECLARE @MABM CHAR(5)
	SELECT @MABM = GV.MABM FROM inserted I INNER JOIN GIAOVIEN GV ON I.MAGV = GV.MAGV

	DECLARE @MADT CHAR(5)
	SELECT @MADT = MADT FROM inserted

	IF(NOT EXISTS(SELECT MADT FROM DETAI DT INNER JOIN GIAOVIEN GV ON DT.GVCNDT = GV.MAGV WHERE GV.MABM = @MABM AND DT.MADT = @MADT))
	BEGIN
		raiserror (N'Lỗi: Giáo viên chỉ tham gia những đề tài mà giáo viên chủ nhiệm đề tài là người cùng bộ môn với giáo viên đó.', 16, 1)
		rollback
	END
END

DROP TRIGGER trgMAGV_THAMGIADT

insert into THAMGIADT values ('003','006',1,1,N'Đạt')

DELETE FROM THAMGIADT
WHERE MAGV = '003' AND MADT = '006' 